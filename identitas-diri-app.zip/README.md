# Aplikasi Identitas Diri

Aplikasi web sederhana berbasis HTML dan JavaScript untuk mengisi data pribadi, kontak, alamat, dan dokumen.

## Fitur

- Form data pribadi (nama, tanggal lahir, jenis kelamin, foto)
- Form kontak (telepon dan email)
- Form alamat (negara, kota, alamat lengkap)
- Upload dokumen (KTP dan SIM)

## Teknologi

- HTML
- CSS
- JavaScript
- Font Awesome

## Cara Menjalankan

1. Clone repositori ini:
   ```bash
   git clone https://github.com/username/identitas-diri-app.git
   ```
2. Buka `index.html` di browser Anda.

## Lisensi

Proyek ini bebas digunakan untuk tujuan pembelajaran dan pengembangan pribadi.
